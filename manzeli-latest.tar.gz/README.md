This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploying to Vercel

1. Push this repo to GitHub and [import it into Vercel](https://vercel.com/new).
2. In the Vercel project's **Settings → Environment Variables**, add the variables listed in [`.env.example`](.env.example):

   | Variable | Where to find it | Exposed to browser? |
   | --- | --- | --- |
   | `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API | Yes |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Project Settings → API | Yes |
   | `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Project Settings → API (service_role secret) | **No — server only** |
   | `NEXT_PUBLIC_SITE_URL` | Your production URL, e.g. `https://manzeli.vercel.app` | Yes |

   Variables prefixed `NEXT_PUBLIC_` are bundled into client code; everything else (like the service role key, used in `app/_actions/admin.ts` to create host accounts) stays server-side only.
3. Deploy. Vercel runs `next build` automatically — to verify locally first, run `npm run build`.
4. Once live, confirm `/sitemap.xml`, `/robots.txt`, and a listing's `/chalets/[slug]/opengraph-image` render correctly with `NEXT_PUBLIC_SITE_URL` pointing at your production domain.

